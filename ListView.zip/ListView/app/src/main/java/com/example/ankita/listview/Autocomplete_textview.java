package com.example.ankita.listview;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;


/**
 * Created by Ankita on 6/20/2017.
 */
public class Autocomplete_textview extends Activity {
    AutoCompleteTextView at;
    ArrayAdapter<String> adapter;
    String[] abc={"abc", "hcg", "acvg","hxcvb"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        at=(AutoCompleteTextView)findViewById(R.id.at);
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,abc);
        at.setAdapter(adapter);
        at.setThreshold(1);
    }

}
