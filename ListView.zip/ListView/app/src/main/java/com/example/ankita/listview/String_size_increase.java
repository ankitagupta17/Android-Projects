package com.example.ankita.listview;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class String_size_increase extends ActionBarActivity {
    ListView lv;
    ArrayAdapter<String> adapter;
    String[] color;
    //String[] abc={"abc", "hcg"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv=(ListView)findViewById(R.id.list);
        color=getResources().getStringArray(R.array.color);
        //adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,color);//used in string size change

        adapter=new ArrayAdapter<String>(this,R.layout.change_size_of_text_in_list,color);//used in text size change

        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch(position){
                    case 0:
                        Intent i=new Intent(String_size_increase.this,Blue.class);
                        startActivity(i);
                        break;
                    case 1:
                        Intent i1=new Intent(String_size_increase.this,Blue.class);
                        startActivity(i1);
                        break;
                    case 2:
                        Intent i2=new Intent(String_size_increase.this,Blue.class);
                        startActivity(i2);
                        break;
                    case 3:
                        Intent i3=new Intent(String_size_increase.this,Blue.class);
                        startActivity(i3);
                        break;
                    case 4:
                        Intent i4=new Intent(String_size_increase.this,Blue.class);
                        startActivity(i4);
                        break;
                    case 5:
                        Intent i5=new Intent(String_size_increase.this,Blue.class);
                        startActivity(i5);
                        break;
                    case 6:
                        Intent i6=new Intent(String_size_increase.this,Blue.class);
                        startActivity(i6);
                        break;
                    case 7:
                        Intent i7=new Intent(String_size_increase.this, Blue.class);
                        startActivity(i7);
                        break;


                }
            }
        });
    }

}
