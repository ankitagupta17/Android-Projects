package com.example.user.interfragmentexample;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


public class MainActivity extends Activity  implements Comm {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public void respond(int position) {
        FragmentManager manager=getFragmentManager();
        Frag2 f2=(Frag2)manager.findFragmentById(R.id.fragment2);
        f2.Changedata(position);

    }
}
