package com.example.user.interfragmentexample;

/**
 * Created by user on 5/13/2016.
 */
public interface Comm  {
    public void respond(int position);
}
