package com.example.user.interfragmentexample;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

/**
 * Created by user on 5/13/2016.
 */
public class Frag1 extends Fragment implements AdapterView.OnItemClickListener {
    ListView lv;
    Comm com;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag1,container,false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        lv=(ListView)getActivity().findViewById(R.id.lv);
        com=(Comm)getActivity();
        ArrayAdapter adapter=ArrayAdapter.createFromResource(getActivity(), R.array.names, android.R.layout.simple_list_item_1);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(this);
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        com.respond(position);
        Intent intent=new Intent(getActivity(),Secondactivity.class);
        startActivity(intent);

    }
}


