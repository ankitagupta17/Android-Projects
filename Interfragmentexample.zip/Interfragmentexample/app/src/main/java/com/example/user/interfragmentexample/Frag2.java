package com.example.user.interfragmentexample;

import android.app.Fragment;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ResourceBundle;

/**
 * Created by user on 5/13/2016.
 */
public class Frag2 extends Fragment {
    TextView tv;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag2,container,false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        tv=(TextView)getActivity().findViewById(R.id.textView);
    }
     public void Changedata(int position){
         Resources r=getResources();
         String[] information = r.getStringArray(R.array.information);
         tv.setText(information[position]);
    }
}
