package com.messagechamber;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class Sch_PendingIntentsArrayAdapter extends ArrayAdapter<Sch_SMSSchedulerPendingIntent> /*implements OnClickListener*/{
	private List<Sch_SMSSchedulerPendingIntent> mPendingIntentList;
	private Context mContext;
	//final String newLine = System.getProperty("line.seperator");
	String newL = System.getProperty("line.separator");
	String messageAlertDialog;
	long mIdOfAnAlarm;
	private Sch_CancelAnAlarmActivity mSchCancelAnAlarmActivity;
	public Sch_PendingIntentsArrayAdapter(Context context, int resource,
			/*int textViewResourceId,*/ List<Sch_SMSSchedulerPendingIntent> objects) {
		super(context, R.layout.sch_cancelanalarm, /*textViewResourceId,*/ objects);
		// TODO Auto-generated constructor stub
		mContext = context;
		mPendingIntentList = objects;
		mSchCancelAnAlarmActivity = Sch_CancelAnAlarmActivity.getCancelAlarmActivity();
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		// First let's verify the convertView is not null
	    if (convertView == null) {
	        // This a new view we inflate the new layout
	        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	        convertView = inflater.inflate(R.layout.sch_cancelanalarm, parent, false);
	    }
	    TextView hr = (TextView)convertView.findViewById(R.id.textViewHr);
	    TextView hrValue = (TextView)convertView.findViewById(R.id.textViewHrValue);
	    
	    TextView mins = (TextView)convertView.findViewById(R.id.textViewMins);
	    TextView minsValue = (TextView)convertView.findViewById(R.id.textViewMinsValue);
	    
	    TextView secs = (TextView)convertView.findViewById(R.id.textViewSecs);
	    TextView secsValue = (TextView)convertView.findViewById(R.id.textViewSecsValue);
	
	    TextView day = (TextView)convertView.findViewById(R.id.textViewDay);
	    TextView dayValue = (TextView)convertView.findViewById(R.id.textViewDayValue);
	    
	    TextView month = (TextView)convertView.findViewById(R.id.textViewMonth);
	    TextView monthValue = (TextView)convertView.findViewById(R.id.textViewMonthValue);
	    
	    TextView year = (TextView)convertView.findViewById(R.id.textViewYear);
	    TextView yearValue = (TextView)convertView.findViewById(R.id.textViewYearValue);
	    
	    //TextView details = (TextView)convertView.findViewById(R.id.textViewDetails);
	    
	    //TextView frequency = (TextView)convertView.findViewById(R.id.textViewFrequency);
	    //TextView frequencyValue = (TextView)convertView.findViewById(R.id.textViewFrequencyValue);
	    //Button detailsButton = (Button)convertView.findViewById(R.id.buttonDetails);
	   // Button cancelButton = (Button)convertView.findViewById(R.id.buttonCancel);
	    
	    Sch_SMSSchedulerPendingIntent schSmsSchedulerPendingIntent = mPendingIntentList.get(position);
	    String receiverNumber = schSmsSchedulerPendingIntent.getNumberToSend();
	    String receiverName = schSmsSchedulerPendingIntent.getReceiverName();
	    String message = schSmsSchedulerPendingIntent.getMessage();
	    String frequency = schSmsSchedulerPendingIntent.getFrequency();
	    /*String newL = System.getProperty("line.separator");*/
	    messageAlertDialog = "Receiver's Number: " + receiverNumber + newL + "Receiver's Name: " + receiverName + newL + "Message: " + message + newL + "Frequency: " + frequency;
	    mIdOfAnAlarm = schSmsSchedulerPendingIntent.getId();
	    if(position == 0){
	    	hr.setText("Hr");
		    mins.setText("Mins");
		    secs.setText("Secs");
		    day.setText("Day");
		    month.setText("Month");
		    year.setText("Year");
		    //frequency.setText("Frequency");
		    //details.setText("Details");
	    }
	    
	    else{
	    	hr.setText("");
		    mins.setText("");
		    secs.setText("");
		    day.setText("");
		    month.setText("");
		    year.setText("");
		    //frequency.setText("");
		    //details.setText("");
	    }
	    
	    hrValue.setText(Long.toString(schSmsSchedulerPendingIntent.getHour()));
	    minsValue.setText(Long.toString(schSmsSchedulerPendingIntent.getMinutes()));
	    secsValue.setText(Long.toString(schSmsSchedulerPendingIntent.getSeconds()));
	    
	    dayValue.setText(Integer.toString(schSmsSchedulerPendingIntent.getDay()));
	    //As usually January means month 1 not month 0. Hence while displaying we need to take care of that
	    monthValue.setText(Integer.toString(schSmsSchedulerPendingIntent.getMonth() + 1));
	    yearValue.setText(Integer.toString(schSmsSchedulerPendingIntent.getYear()));
	    
	     /*detailsButton.setOnClickListener(new OnClickListener() {
	    // Sch_SMSSchedulerPendingIntent currentPendingIntent = mPendingIntentList.get(position);
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//Toast.makeText(getApplicationContext(), text, duration)
				mSchCancelAnAlarmActivity.ShowCancelAlarmDetails(messageAlertDialog);
			}
		});
	     cancelButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mSchCancelAnAlarmActivity.CancelAnAlarm(mIdOfAnAlarm);
			}
		});
		*/	
	    //frequencyValue.setText(schSmsSchedulerPendingIntent.getFrequency());
	    return convertView;
	}
	
	public List<Sch_SMSSchedulerPendingIntent> getPendingIntentList(){
		return mPendingIntentList;
	}

	/*@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}*/
	
	

}
