package com.messagechamber;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Toast;

import java.util.ArrayList;

public class View_msg extends AppCompatActivity  {
    Datat dt;
    TextView tv;
    /*Button btn2;
    String SmsMessageStr;
    ArrayList<String> smsMessagesList = new ArrayList<String>();
*/
    StringBuffer buffer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_msg);
        dt= new Datat(this);
        tv=(TextView)findViewById(R.id.textView2);
        // btn2=(Button)findViewById(R.id.button3);
        retrieve();
       // delete();
    }
    public void retrieve()
    {

        Cursor res = dt.fetch();
        if (res.getColumnCount() == 0)
        {
            Toast.makeText(View_msg.this, "No messages found!!", Toast.LENGTH_LONG).show();
        }
        buffer = new StringBuffer();

        while (res.moveToNext())
        {
            buffer.append("Msg: " + res.getString(0) + "\n\n");
        }

        tv.setText(buffer);
    }
    public void show(View view) {
        retrieve();

    }

    @Override
    protected void onPause()
    {

        super.onPause();
        finish();
    }
    /*public void popup(String title,String message){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(true);
        builder.show();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        try {
            String[] smsMessages = smsMessagesList.get(position).split("\n");
            String address = smsMessages[0];
            String smsMessage = "";
            for (int i = 1; i < smsMessages.length; ++i) {
                smsMessage += smsMessages[i];
            }
            String smsMessageStr = address + "\n";
            smsMessageStr += smsMessage;
            Toast.makeText(this, smsMessageStr, Toast.LENGTH_SHORT).show();
            SmsMessageStr = smsMessageStr;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/


    public void delete() {

        Integer deletedrow = dt.dlt(buffer);
        if (deletedrow > 0) {
            Toast.makeText(View_msg.this, "Message deleted successfully", Toast.LENGTH_SHORT).show();
        } else
        {
            Toast.makeText(View_msg.this, "Message deletion is unsuccessfully", Toast.LENGTH_SHORT).show();
        }
    }
}
