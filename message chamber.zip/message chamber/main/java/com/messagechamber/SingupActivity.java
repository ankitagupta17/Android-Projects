package com.messagechamber;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SingupActivity extends AppCompatActivity {

    EditText username;
    EditText userpassword;
    EditText userconfirmpassword;
    Button signup;
    TextView loginlink;
    LoginDatabaseAdapter loginDatabaseAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singup);
        username=(EditText)findViewById(R.id.input_name);
        userpassword=(EditText)findViewById(R.id.input_password);
        userconfirmpassword=(EditText)findViewById(R.id.input_confirmpassword);
        loginlink=(TextView)findViewById(R.id.link_login);
        signup=(Button)findViewById(R.id.btn_signup);
        loginDatabaseAdapter=new LoginDatabaseAdapter(this);
        loginDatabaseAdapter=loginDatabaseAdapter.open();

        loginlink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SingupActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });

        signup.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                signup();
            }
        });

    }
public void signup(){

    String name=username.getText().toString();
    String password=userpassword.getText().toString();
    String confirmpassword=userconfirmpassword.getText().toString();

    if(name.equals("")||password.equals("")||confirmpassword.equals(""))
    {
        Toast.makeText(getApplicationContext(), "Field Vaccant", Toast.LENGTH_LONG).show();
        return;
    }
    // check if both password matches
    if(!password.equals(confirmpassword))
    {
        Toast.makeText(getApplicationContext(), "Password does not match", Toast.LENGTH_LONG).show();
        return;
    }
    else
    {
        // Save the Data in Database
        loginDatabaseAdapter.insertEntry(name, password);
        Toast.makeText(getApplicationContext(), "Account Successfully Created ", Toast.LENGTH_LONG).show();
        Intent intent=new Intent(SingupActivity.this,LoginActivity.class);
        startActivity(intent);

    }

}
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close The Database
        loginDatabaseAdapter.close();
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
