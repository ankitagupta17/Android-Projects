package com.messagechamber;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {


    EditText username;
    EditText userpassword;
    TextView signuplink;
    Button login;
    LoginDatabaseAdapter loginDatabaseAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username=(EditText)findViewById(R.id.input_username);
        userpassword=(EditText)findViewById(R.id.input_password);
        signuplink=(TextView)findViewById(R.id.link_signup);
        login=(Button)findViewById(R.id.btn_login);
        loginDatabaseAdapter=new LoginDatabaseAdapter(this);
        loginDatabaseAdapter=loginDatabaseAdapter.open();

        signuplink.setOnClickListener(new View.OnClickListener() {
         @Override
          public void onClick(View v) {
            Intent intent=new Intent(LoginActivity.this,SingupActivity.class);
             startActivity(intent);
         }


       });

        login.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {
                login();
            }
        });
    }


    public void login(){
     String name=username.getText().toString();
     String password=userpassword.getText().toString();
        String storedPassword=loginDatabaseAdapter.getSinlgeEntry(name);
        if(password.equals(storedPassword))
        {
            //Toast.makeText(HomeActivity.this, "Congrats: Login Successfull", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(LoginActivity.this,Navig_draw.class);
            startActivity(intent);



        }
        else
        {
            Toast.makeText(LoginActivity.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
        }




    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close The Database
        loginDatabaseAdapter.close();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();;
        this.finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
