package com.messagechamber;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Toast;


public class SmsActivity extends AppCompatActivity implements OnItemClickListener {

    Datat dt;
    String SmsMessageStr;
    ListView lv,lv1;
    ListView smsListView;
    TextView tv;
    Button btn,btn1;
    private static SmsActivity inst;
    ArrayList<String> smsMessagesList = new ArrayList<String>();
    ArrayAdapter arrayAdapter;

    public static SmsActivity instance()
    {
        return inst;
    }
    @Override
    public void onStart() {
        super.onStart();
        inst = this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        tv=(TextView)findViewById(R.id.textView2);
        btn=(Button)findViewById(R.id.button);
        btn1=(Button)findViewById(R.id.button2);
        //lv1=(ListView)findViewById(R.id.listView3);
        lv=(ListView)findViewById(R.id.listView);
        smsListView = (ListView) findViewById(R.id.SMSList);
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, smsMessagesList);
        smsListView.setAdapter(arrayAdapter);
        smsListView.setOnItemClickListener(this);
        refreshSmsInbox();
        dt=new Datat(this);
       // retrieve();
        insert();
        // delete();
    }
    public void refreshSmsInbox() {
        ContentResolver contentResolver = getContentResolver();
        Cursor smsInboxCursor = contentResolver.query(Uri.parse("content://sms/inbox"), null, null, null, null);
        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        if (indexBody < 0 || !smsInboxCursor.moveToFirst()) return;
        arrayAdapter.clear();
        do {
            String str = "SMS From: " + smsInboxCursor.getString(indexAddress) +
                    "\n" + smsInboxCursor.getString(indexBody) + "\n";
            arrayAdapter.add(str);
        } while (smsInboxCursor.moveToNext());
    }

    public void updateList(final String smsMessage) {
        arrayAdapter.insert(smsMessage, 0);
        arrayAdapter.notifyDataSetChanged();
    }

    public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
        try {
            String[] smsMessages = smsMessagesList.get(pos).split("\n");
            String address = smsMessages[0];
            String smsMessage = "";
            for (int i = 1; i < smsMessages.length; ++i) {
                smsMessage += smsMessages[i];
            }
            String smsMessageStr = address + "\n";
            smsMessageStr += smsMessage;
            Toast.makeText(this, smsMessageStr, Toast.LENGTH_SHORT).show();
             SmsMessageStr = smsMessageStr;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void insert(){
        smsListView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                boolean inserted = dt.ins(smsListView.getItemAtPosition(position).toString());
                if (inserted == true) {
                    Toast.makeText(SmsActivity.this, "data inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SmsActivity.this, "data not inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
   public void show(View view){
        Intent intent=new Intent(SmsActivity.this, View_msg.class);
        startActivity(intent);
    }
  /*  public void retrieve(){
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                Cursor res = dt.fetch();
                if (res.getColumnCount() == 0) {
                    popup("sorry", "no data found");
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("data is " + res.getString(0));


                }tv.setText(buffer);


            }
        });

    }
    public void popup(String title,String message){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(true);
        builder.show();
    }


    /*public void delete() {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deletedrow = dt.dlt(buffer);
                if (deletedrow > 0) {
                    Toast.makeText(SmsActivity.this, "Data is deleted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SmsActivity.this, "Data deletion is unsuccessfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }*/
}