package com.messagechamber;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Compose_msg extends AppCompatActivity implements View.OnClickListener {
EditText ed1,ed2;
    private String mContactdisplayName;
    Button mButtonContact;
    EditText mEditTextNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compose_msg);
        //ed1 = (EditText)findViewById(R.id.ph_no);
        ed2 = (EditText)findViewById(R.id.msg_area);
        mButtonContact = (Button)findViewById(R.id.buttonContact);
        mEditTextNumber = (EditText)findViewById(R.id.ph_no);
       // mButtonContact = (Button)findViewById(R.id.buttoncontact1);
        mButtonContact.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
                startActivityForResult(intent, 1);
            }
        });
    }

    public void sub(View view)
    {
        String phonenum=mEditTextNumber.getText().toString();
        String message=ed2.getText().toString();
        SmsManager manager=SmsManager.getDefault();
        manager.sendTextMessage(phonenum, null, message, null, null);
        Toast.makeText(this, "Message sent", Toast.LENGTH_SHORT).show();

        Intent refresh = new Intent();
        refresh.setClassName("com.messagechamber", "com.messagechamber.Navig_draw");
        startActivity(refresh);
    }
    public void cancel(View view)
    {
        Intent intent= new Intent(this, Navig_draw.class);
        startActivity(intent);
    }

    public void onStop(){
        super.onStop();
    }

    public void onBackPressed() {
        //exit the app
        finish();
    }
    public void onPause(){
        super.onPause();
        finish();
    }
    @Override
    public void onResume(){
        super.onResume();}

    public void onDestroy(){
        super.onDestroy();}


    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu4, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_sch_msg) {
            Intent intent= new Intent(this, Sch_SetuppageActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }




    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data != null) {
            Uri uri = data.getData();

            if (uri != null) {
                Cursor c = null;
                try {
                    c = getContentResolver().query(uri, new String[]{
                                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                                    ContactsContract.CommonDataKinds.Phone.TYPE,
                                    ContactsContract.CommonDataKinds.Identity.DISPLAY_NAME},
                            null, null, null);

                    if (c != null && c.moveToFirst()) {
                        //mNumber = c.getString(0);
                        int type = c.getInt(1);
                        mEditTextNumber.setText(c.getString(0));
                        mContactdisplayName = c.getString(2);
                    }
                } finally {
                    if (c != null) {
                        c.close();
                    }
                }
            }
        }
    }

    @Override
    public void onClick(View v) {

    }
}
