package com.messagechamber;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class Sch_PendingIntentsDataSource {

	// Database fields
	  private SQLiteDatabase database;
	  private Sch_PendingIntentSQLiteHelper dbHelper;
	  private String[] allColumns = { Sch_PendingIntentSQLiteHelper.COLUMN_ID, Sch_PendingIntentSQLiteHelper.COLUMN_HOUR, Sch_PendingIntentSQLiteHelper.COLUMN_MINUTES, Sch_PendingIntentSQLiteHelper.COLUMN_SECONDS, Sch_PendingIntentSQLiteHelper.COLUMN_YEAR, Sch_PendingIntentSQLiteHelper.COLUMN_MONTH, Sch_PendingIntentSQLiteHelper.COLUMN_DAY, Sch_PendingIntentSQLiteHelper.COLUMN_FREQUENCY, Sch_PendingIntentSQLiteHelper.COLUMN_NUMBERTOSEND, Sch_PendingIntentSQLiteHelper.COLUMN_RECEIVERNAME, Sch_PendingIntentSQLiteHelper.COLUMN_MESSAGE };
	  
	  public Sch_PendingIntentsDataSource(Context context){
		  dbHelper = new Sch_PendingIntentSQLiteHelper(context, "pendingintents.db",null, 2);
	  }
	  
	  public void open() throws SQLException {
		    database = dbHelper.getWritableDatabase();
		  }
	  
	  public void close() {
		    dbHelper.close();
		  }
	  
	  public Sch_SMSSchedulerPendingIntent createPendingIntents(int id, int hour, int mins, int secs, int year, int month, int day, String frequency, String number, String name, String message ){
		  ContentValues values = new ContentValues();
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_ID, id);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_HOUR, hour);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_MINUTES, mins);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_SECONDS, secs);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_YEAR, year);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_MONTH, month);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_DAY, day);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_FREQUENCY, frequency);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_NUMBERTOSEND, number);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_RECEIVERNAME, name);
		  values.put(Sch_PendingIntentSQLiteHelper.COLUMN_MESSAGE, message);
		  
		  database.insert(Sch_PendingIntentSQLiteHelper.TABLE_PENDINGINTENT, null,
			        values);
		  
		  Cursor cursor = database.query(Sch_PendingIntentSQLiteHelper.TABLE_PENDINGINTENT,
			        allColumns, Sch_PendingIntentSQLiteHelper.COLUMN_ID + " = " + id, null,
			        null, null, null);
		  
		  cursor.moveToFirst();
		  Sch_SMSSchedulerPendingIntent newPendingIntent = cursorToPendingIntent(cursor);
		  cursor.close();
		  return newPendingIntent;
	  }
	  
	  public List<Sch_SMSSchedulerPendingIntent> getAllPendingIntents() {
		  List<Sch_SMSSchedulerPendingIntent> pendingIntents = new ArrayList<Sch_SMSSchedulerPendingIntent>();
		  Cursor cursor = database.query(Sch_PendingIntentSQLiteHelper.TABLE_PENDINGINTENT,
			        allColumns, null, null, null, null, null);
		  
		  cursor.moveToFirst();
		    while (!cursor.isAfterLast()) {
		    	Sch_SMSSchedulerPendingIntent pendingIntent = cursorToPendingIntent(cursor);
		    	pendingIntents.add(pendingIntent);
		      cursor.moveToNext();
		    }
		    // Make sure to close the cursor
		    cursor.close();
		    return pendingIntents;
	  }
	  
	  private Sch_SMSSchedulerPendingIntent cursorToPendingIntent(Cursor cursor) {
		  Sch_SMSSchedulerPendingIntent pendingIntent = new Sch_SMSSchedulerPendingIntent();
		  pendingIntent.setId(cursor.getLong(0));
		  pendingIntent.setHour(cursor.getInt(1));
		  pendingIntent.setMinutes(cursor.getInt(2));
		  pendingIntent.setSeconds(cursor.getInt(3));
		  pendingIntent.setYear(cursor.getInt(4));
		  pendingIntent.setMonth(cursor.getInt(5));
		  pendingIntent.setDay(cursor.getInt(6));
		  pendingIntent.setFrequency(cursor.getString(7));
		  pendingIntent.setNumberToSend(cursor.getString(8));
		  pendingIntent.setReceiverName(cursor.getString(9));
		  pendingIntent.setMessage(cursor.getString(10));
		  
		  return pendingIntent;
		  }
	  
	  public boolean deletePendingIntent(int id) 
		{
		 
		      return database.delete(Sch_PendingIntentSQLiteHelper.TABLE_PENDINGINTENT, Sch_PendingIntentSQLiteHelper.COLUMN_ID + "=" + id, null) > 0;
		  
		}
}
