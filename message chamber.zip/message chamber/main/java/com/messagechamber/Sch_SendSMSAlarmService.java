package com.messagechamber;


import java.util.ArrayList;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.telephony.SmsManager;

public class Sch_SendSMSAlarmService extends Service {
 private String mNumberToSend;
 private String mSMSMessage;
 private String mFrequency;
 private int mId;
 private Sch_CancelAnAlarmActivity mSchCancelAnAlarmActivity;
 //Sch_SetuppageActivity mSetupPageActivity;
 private Sch_PendingIntentsDataSource mDatasource;
 
 @Override
 public void onCreate() {
  // TODO Auto-generated method stub
	 super.onCreate();
	 //mSetupPageActivity = Sch_SetuppageActivity.getMAinActivity();
	 mSchCancelAnAlarmActivity = Sch_CancelAnAlarmActivity.getCancelAlarmActivity();
	 
 }

 @Override
 public IBinder onBind(Intent arg0) {
  // TODO Auto-generated method stub
	 
  return null;
 }
 
 @Override
 public void onDestroy() {
  // TODO Auto-generated method stub
   super.onDestroy();
   //Toast.makeText(this, "MyAlarmService.onDestroy()", Toast.LENGTH_LONG).show();
   mDatasource.close();
 }

@Override
 public int onStartCommand(Intent intent, int startId, int arg) {
  // TODO Auto-generated method stub
  super.onStartCommand(intent, startId, arg);
  
 // Bundle bundle = intent.getExtras();
  	mNumberToSend = intent.getStringExtra("com.messagechamber.number");
  	
  	mSMSMessage = intent.getStringExtra("com.messagechamber.message");
  	mFrequency = intent.getStringExtra("com.messagechamber.frequency");
  	mId = intent.getIntExtra("com.messagechamber.id", 0);
  	SmsManager sms = SmsManager.getDefault();
  	
  	if(!mSMSMessage.equals(null)){
  		
  		ArrayList<String> msgStringArray = sms.divideMessage(mSMSMessage);      

  	    sms.sendMultipartTextMessage(mNumberToSend, null, msgStringArray, null, null);
  	}
  	
  	if(mFrequency.equalsIgnoreCase("Once")){
  	mDatasource = new Sch_PendingIntentsDataSource(getApplicationContext());
    mDatasource.open();
    mDatasource.deletePendingIntent(mId);
    //mDatasource.close();*/
  	//mSchCancelAnAlarmActivity.DeleteAnForOnceAlarmEntryFromDatabase(mId);
  	}
  	
  	return START_STICKY_COMPATIBILITY;
  
    //sms.sendTextMessage(mNumberToSend, null, mSMSMessage, null, null);
 }

 @Override
 public boolean onUnbind(Intent intent) {
  // TODO Auto-generated method stub
	// mDatasource.close();
  return super.onUnbind(intent);
  
 }

}