package com.example.ankita.test1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;

/**
 * Created by Ankita on 6/13/2017.
 */
public class Clickbuttons extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clickbuttons);
    }
    public void b1(View v)
    {
        Intent i1=new Intent(this, First.class);
        startActivity(i1);
    }
    public void b2(View v1)
    {
        Intent i2=new Intent(this, Buttonsclass.class);
        startActivity(i2);
    }

}
