package com.example.ankita.test1;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Ankita on 6/8/2017.
 */
public class Buttonsclass extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buttonclass);
    }
}
