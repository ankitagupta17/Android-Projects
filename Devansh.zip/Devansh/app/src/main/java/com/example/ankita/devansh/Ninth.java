package com.example.ankita.devansh;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;

/**
 * Created by Ankita on 6/17/2017.
 */
public class Ninth extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ninth);

    }
    public void button15(View v)
    {
        Intent i=new Intent(this,Tenth.class);
        startActivity(i);
    }
}
