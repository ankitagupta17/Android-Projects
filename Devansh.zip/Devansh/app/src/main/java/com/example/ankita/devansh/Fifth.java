package com.example.ankita.devansh;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;

/**
 * Created by Ankita on 6/17/2017.
 */
public class Fifth extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fifth);
    }
    public void button6(View v)
    {
        Intent i=new Intent(this,Pic1.class);
        startActivity(i);
    }
    public void button7(View v)
    {
        Intent i=new Intent(this,Pic2.class);
        startActivity(i);
    }
    public void button8(View v)
    {
        Intent i=new Intent(this,Pic3.class);
        startActivity(i);
    }
    public void button9(View v)
    {
        Intent i=new Intent(this,Pic4.class);
        startActivity(i);
    }
    public void button10(View v)
    {
        Intent i=new Intent(this,Pic5.class);
        startActivity(i);
    }
    public void button11(View v)
    {
        Intent i=new Intent(this,Sixth.class);
        startActivity(i);
    }
}
