package com.example.ankita.devansh;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;

/**
 * Created by Ankita on 6/17/2017.
 */
public class Third extends ActionBarActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third);

    }
    public void button4(View v)
    {
        Intent i=new Intent(this,Fourth.class);
        startActivity(i);
    }
}
