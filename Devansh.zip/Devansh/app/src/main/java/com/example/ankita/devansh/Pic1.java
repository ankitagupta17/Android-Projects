package com.example.ankita.devansh;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;

/**
 * Created by Ankita on 6/17/2017.
 */
public class Pic1 extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pic1);
    }
    public void btn1(View v)
    {
        Intent i=new Intent(this,Fifth.class);
        startActivity(i);
    }
}
