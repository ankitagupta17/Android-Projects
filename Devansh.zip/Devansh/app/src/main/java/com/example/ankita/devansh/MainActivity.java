package com.example.ankita.devansh;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MediaPlayer happys = MediaPlayer.create(MainActivity.this,R.raw.happys);
        happys.start();
    }
    public void button1(View v)
    {
        Intent i=new Intent(this,First.class);
        startActivity(i);
    }

}
