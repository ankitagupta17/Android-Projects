package com.example.ankita.database;

        import android.content.ContentValues;
        import android.content.Context;
        import android.content.Intent;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Ankita on 6/23/2017.
 */
public class Datat extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="datag";
    public static final String TABLE_NAME="tab";
    public static final String COL_1="NAME";
    public static final String COL_2="COLLEGENAME";

    public Datat(Context context)
    {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db=this.getWritableDatabase();
    }
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table " + TABLE_NAME + "(NAME TEXT,COLLEGENAME TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME, null);
    }
    public boolean ins(String name, String collegename)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL_1, name);
        contentValues.put(COL_2, collegename);
        db.insert(TABLE_NAME, null, contentValues);
        return true;
    }
    public Cursor fetch()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor res=db.rawQuery("select * from " + TABLE_NAME, null);
        return  res;
    }
    public boolean upt(String name, String collegename)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL_1, name);
        contentValues.put(COL_2, collegename);
        db.update(TABLE_NAME, contentValues, "COLLEGENAME = ? ", new String[]{collegename});
        return true;
    }
    public Integer dlt(String collegename)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Integer res=db.delete(TABLE_NAME, " COLLEGENAME = ? ", new String[]{collegename});
        return res;
    }
}
