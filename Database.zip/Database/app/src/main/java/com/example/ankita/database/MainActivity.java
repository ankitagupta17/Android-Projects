package com.example.ankita.database;

import android.app.AlertDialog;
import android.database.Cursor;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {
    Datat dt;
    EditText e1, e2;
    Button b1, b2, b3, b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=(EditText)findViewById(R.id.editText);
        e2=(EditText)findViewById(R.id.editText2);
        b1=(Button)findViewById(R.id.button4);
        b2=(Button)findViewById(R.id.button);
        b3=(Button)findViewById(R.id.button2);
        b4=(Button)findViewById(R.id.button3);
        dt=new Datat(this);
        insertt();
        retrieve();
        update();
        delete();
    }
public void insertt()
{
    b1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            boolean datainserted =dt.ins(e1.getText().toString(), e2.getText().toString());
            if(e1==null && e2==null)
            {
                Toast.makeText(MainActivity.this, "Please insert data", Toast.LENGTH_SHORT).show();
            }
            else {
                if(datainserted == true)
                {
                    Toast.makeText(MainActivity.this, "Data is inserted successfully", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Data insertion is unsuccessfully", Toast.LENGTH_SHORT).show();
                }
            }
        }

    });
}
    public void retrieve()
    {
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = dt.fetch();
                if (res.getColumnCount() == 0) {
                    nmessage("sorry", "no data found");
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("name is" + res.getString(0) + "\n\n");
                }
                nmessage("data", buffer.toString());
            }
        });
    }
    public void nmessage(String title, String message)
    {
        AlertDialog.Builder alertBuilder=new AlertDialog.Builder(this);
        alertBuilder.setTitle(title);
        alertBuilder.setMessage(message);
        alertBuilder.setCancelable(true);
        alertBuilder.show();

}
    public void update()
    {
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean dataupdated = dt.upt(e1.getText().toString(), e2.getText().toString());
                if (dataupdated == true) {
                    Toast.makeText(MainActivity.this, "Data is updated successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Data updation is unsuccessfully", Toast.LENGTH_SHORT).show();
                }
            }


        });

    }
   public void delete()
   {
    b4.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Integer deletedrow=dt.dlt(e2.getText().toString());
            if(deletedrow>0)
            {
                Toast.makeText(MainActivity.this, "Data is deleted successfully", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(MainActivity.this, "Data deletion is unsuccessfully", Toast.LENGTH_SHORT).show();
            }
        }
    });
   }
}
