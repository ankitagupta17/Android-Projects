package com.example.user.bluetooth;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;


public class MainActivity extends Activity {

    ListView lv;
    private BluetoothAdapter BA;
    private Set<BluetoothDevice>paireddevices;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv=(ListView)findViewById(R.id.listView);
        BA=BluetoothAdapter.getDefaultAdapter();
    }
    public void on(View view) {
        if (!BA.isEnabled()){
        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(intent, 0);
        Toast.makeText(MainActivity.this, "Bluthooth is ON", Toast.LENGTH_SHORT).show();}
        else {
            Toast.makeText(MainActivity.this, "Bluthooth is already ON",
                    Toast.LENGTH_SHORT).show();
        }}
    public void off(View view){
        BA.disable();
        Toast.makeText(MainActivity.this
                ,"Bluthooth is OFF",Toast.LENGTH_SHORT).show();
    }
    public void visible(View view){
        Intent intent=new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        startActivityForResult(intent, 0);
        Toast.makeText(MainActivity.this,"Bluthooth "+"device is VISIBLE"
                ,Toast.LENGTH_SHORT).show();
    }
    public void pair(View view){
        paireddevices=BA.getBondedDevices();
        ArrayList list=new ArrayList();
        for (BluetoothDevice bt: paireddevices)
        list.add(bt.getName());
        final ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,list);
        lv.setAdapter(adapter);
    }

}