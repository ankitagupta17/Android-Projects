package com.example.ankita.menuclasswork;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.m1)
        {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            Toast.makeText(this, "Login is selected", Toast.LENGTH_LONG).show();
        }
        else if (id == R.id.m2) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            Toast.makeText(this, "Logout is selected", Toast.LENGTH_LONG).show();
        } else {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            Toast.makeText(this, "Help is needed", Toast.LENGTH_LONG).show();
        }
        return true;
    }
}


