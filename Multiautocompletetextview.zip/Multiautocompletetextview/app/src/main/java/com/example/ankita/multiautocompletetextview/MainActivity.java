package com.example.ankita.multiautocompletetextview;

import android.app.Activity;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;


public class MainActivity extends Activity {
    //AutoCompleteTextView at;
    MultiAutoCompleteTextView mt;
    ArrayAdapter<String> adapter;
    String[] abc={"abc", "hcg", "acvg","hxcvb"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //at=(AutoCompleteTextView)findViewById(R.id.at);
        mt=(MultiAutoCompleteTextView)findViewById(R.id.mt);
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,abc);
        //at.setAdapter(adapter);
        //at.setThreshold(1);
        mt.setAdapter(adapter);
        mt.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        mt.setThreshold(1);
    }

}
