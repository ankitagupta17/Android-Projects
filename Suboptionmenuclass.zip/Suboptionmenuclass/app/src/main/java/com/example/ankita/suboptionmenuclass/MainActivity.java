package com.example.ankita.suboptionmenuclass;

import android.graphics.Color;
import android.os.PersistableBundle;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity {
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=(TextView)findViewById(R.id.txt);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.red:
                tv.setTextColor(Color.RED);
                break;
            case R.id.blue:
                tv.setTextColor(Color.BLUE);
                break;
            case R.id.green:
                tv.setTextColor(Color.GREEN);
                break;
            case R.id.bred:
                tv.setBackgroundColor(Color.RED);
                break;
            case R.id.bblue:
                tv.setBackgroundColor(Color.BLUE);
                break;
            case R.id.bgreen:
                tv.setBackgroundColor(Color.GREEN);
                break;
        }
        return true;

    }
}
