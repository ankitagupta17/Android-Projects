package com.example.ankita.suboptionmenuclass;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Ankita on 6/16/2017.
 */
public class Buttoncreation extends ActionBarActivity {
    Button btn;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buttoncreation);
        btn = (Button) findViewById(R.id.btnn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Buttoncreation.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
}