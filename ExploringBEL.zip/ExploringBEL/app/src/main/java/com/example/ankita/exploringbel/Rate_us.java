package com.example.ankita.exploringbel;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RatingBar;
import android.widget.Toast;

/**
 * Created by Ankita on 6/25/2017.
 */
public class Rate_us extends AppCompatActivity{

    RatingBar ratingBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rateus);
        ratingBar=(RatingBar)findViewById(R.id.rate);
    }
    public void onBtnClick(View v)
    {
        float ratingvalue=ratingBar.getRating();
        Toast.makeText(Rate_us.this,"Rating is: "+ratingvalue, Toast.LENGTH_SHORT).show();
    }

}
