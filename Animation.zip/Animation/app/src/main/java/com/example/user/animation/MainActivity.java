package com.example.user.animation;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

  public void zoo(View view){
      ImageView im=(ImageView)findViewById(R.id.imageView);
      Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoom);
      im.startAnimation(animation);

 }
    public void bl(View view){
        ImageView im=(ImageView)findViewById(R.id.imageView);
        Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.blink);
        im.startAnimation(animation);

    }
    public void sli(View view){

        ImageView im=(ImageView)findViewById(R.id.imageView);
        Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide);
        im.startAnimation(animation);

    }
    public void fad(View view){
        ImageView im=(ImageView)findViewById(R.id.imageView);
        Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade);
        im.startAnimation(animation);
    }
    public void mov(View view){
        ImageView im=(ImageView)findViewById(R.id.imageView);
        Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.move);
        im.startAnimation(animation);
    }
    public void rot(View view){
        ImageView im=(ImageView)findViewById(R.id.imageView);
        Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
        im.startAnimation(animation);
    }
}
