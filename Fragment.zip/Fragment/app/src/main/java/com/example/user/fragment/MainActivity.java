package com.example.user.fragment;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void show(View view){
        Frag1 f1=new Frag1();
        FragmentManager manager=getFragmentManager();
        FragmentTransaction transaction=manager.beginTransaction();
        transaction.add(R.id.r1,f1,"hello");
        transaction.commit();
    }
    public void show1(View view){
        Frag2 f2=new Frag2();
        FragmentManager manager=getFragmentManager();
        FragmentTransaction transaction=manager.beginTransaction();
        transaction.add(R.id.r1,f2,"hello");
        transaction.commit();
    }
    public void show2(View view){
        Frag3 f3=new Frag3();
        FragmentManager manager=getFragmentManager();
        FragmentTransaction transaction=manager.beginTransaction();
        transaction.add(R.id.r1,f3,"hello");
        transaction.commit();
    }
    public void show3(View view){
        Frag4 f4=new Frag4();
        FragmentManager manager=getFragmentManager();
        FragmentTransaction transaction=manager.beginTransaction();
        transaction.add(R.id.r1,f4,"hello");
        transaction.commit();
    }
    public void show4(View view){
        Frag5 f5=new Frag5();
        FragmentManager manager=getFragmentManager();
        FragmentTransaction transaction=manager.beginTransaction();
        transaction.add(R.id.r1, f5, "hello");
        transaction.commit();
    }

}


