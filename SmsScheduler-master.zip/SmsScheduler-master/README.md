
# SMS Scheduler
An android app which lets you schedule an sms to be sent at a specific time

This app is for you if:

* You keep forgetting to send a birthday sms to someone
* You have that friend who doesn't seem to know what an alarm is

Tested on Android 2.2 and Android 7. Should work on everything in between.