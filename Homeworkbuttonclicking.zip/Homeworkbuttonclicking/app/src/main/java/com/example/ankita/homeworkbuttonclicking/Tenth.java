package com.example.ankita.homeworkbuttonclicking;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by Ankita on 6/13/2017.
 */
public class Tenth extends ActionBarActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tenth);
    }
}
