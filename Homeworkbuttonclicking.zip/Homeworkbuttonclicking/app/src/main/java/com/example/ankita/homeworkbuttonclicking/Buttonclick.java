package com.example.ankita.homeworkbuttonclicking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;

/**
 * Created by Ankita on 6/13/2017.
 */
public class Buttonclick extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buttonclick);
    }
    public void b1(View v1)
    {
        Intent i1=new Intent(this,First.class);
        startActivity(i1);
    }
    public void b2(View v2)
    {
        Intent i2=new Intent(this, Second.class);
        startActivity(i2);
    }
    public void b3(View v3)
    {
        Intent i3=new Intent(this, Third.class);
        startActivity(i3);
    }
    public void b4(View v4)
    {
        Intent i4=new Intent(this,Fourth.class);
        startActivity(i4);
    }
    public void b5(View v5)
    {
        Intent i5=new Intent(this, Fifth.class);
        startActivity(i5);
    }
    public void b6(View v6)
    {
        Intent i6=new Intent(this, Sixth.class);
        startActivity(i6);
    }
    public void b7(View v7)
    {
        Intent i7=new Intent(this,Seventh.class);
        startActivity(i7);
    }
    public void b8(View v8)
    {
        Intent i8=new Intent(this, Eighth.class);
        startActivity(i8);
    }
    public void b9(View v9)
    {
        Intent i9=new Intent(this, Ninth.class);
        startActivity(i9);
    }
    public void b10(View v10)
    {
        Intent i10=new Intent(this,Tenth.class);
        startActivity(i10);
    }
}
