package com.example.ankita.splashscreen;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by Ankita on 6/19/2017.
 */
public class Splashscreen extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);
        Thread thread=new Thread()
        {
            public void run()
            {
                try{
                    sleep(2000);
                }
                catch (Exception e)
                {

                }
                finally {
                    Intent intent=new Intent(Splashscreen.this,MainActivity.class);
                    startActivity(intent);

            }
            }
        };
        thread.start();
    }
    protected void onPause()
    {
        super.onPause();
        finish();
    }
}
