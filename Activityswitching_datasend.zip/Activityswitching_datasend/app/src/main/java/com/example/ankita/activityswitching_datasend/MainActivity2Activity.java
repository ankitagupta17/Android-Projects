package com.example.ankita.activityswitching_datasend;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;

/**
 * Created by Ankita on 6/28/2017.
 */
public class MainActivity2Activity extends ActionBarActivity {
    public static final String MESSAGE_KEY="com.example.ankita.activityswitching_datasend.abc";
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity2);
        tv=(TextView)findViewById(R.id.textView3);
        Intent intent=getIntent();
        String mess=intent.getStringExtra(MESSAGE_KEY);
        tv.setText(mess);
    }
}
