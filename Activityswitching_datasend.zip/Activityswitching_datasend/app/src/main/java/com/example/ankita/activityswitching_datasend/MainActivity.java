package com.example.ankita.activityswitching_datasend;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;


public class MainActivity extends ActionBarActivity {
    public static final String MESSAGE_KEY="com.example.ankita.activityswitching_datasend.abc";
    EditText ed1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=(EditText)findViewById(R.id.editText);
    }
    public void show(View view)
    {
        String mess=ed1.getText().toString();
        Intent intent=new Intent(this,MainActivity2Activity.class);
        intent.putExtra(MESSAGE_KEY,mess);
        startActivity(intent);
    }
}
