package com.example.ankita.menuhomework;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;

/**
 * Created by Ankita on 6/15/2017.
 */
public class Help extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);
    }
    public void home(View v)
    {
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
    }
}
