package com.example.ankita.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by Ankita on 6/23/2017.
 */
public class Battery extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        boolean isBatteryCharging=intent.getBooleanExtra("state", true);
        if(isBatteryCharging)
        {
            Toast.makeText(context, "Battery charging", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(context, "Battery discharging", Toast.LENGTH_LONG).show();

        }

    }
}
