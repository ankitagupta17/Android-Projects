package com.example.ankita.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by Ankita on 6/22/2017.
 */
public class Broad extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
       boolean isAirPlaneModeOn=intent.getBooleanExtra("state", false);
        if(isAirPlaneModeOn)
        {
            Toast.makeText(context, "Airplane mode ONN", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(context, "Airplane mode Off", Toast.LENGTH_LONG).show();

        }

    }
}
